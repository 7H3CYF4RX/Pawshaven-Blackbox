"""
Adoptions Blueprint — Adoption applications, certificates
Vulnerabilities: CSRF (#19), Forced browsing (#7)
"""
from flask import Blueprint, request, jsonify, g, send_file
from middleware.auth_middleware import require_auth
from utils.id_encoder import encode_id, decode_id
from utils import database as db
import os
from config import Config

adoptions_bp = Blueprint('adoptions', __name__)


@adoptions_bp.route('/api/animals/<encoded_id>/adopt', methods=['POST'])
@require_auth
def adopt_animal(encoded_id):
    """
    VULN #19: CSRF — no CSRF token validation on this sensitive endpoint.
    Any external site can trigger adoption application via hidden form.
    """
    res_type, res_id = decode_id(encoded_id)
    if res_type != 'animal' or res_id is None:
        return jsonify({'error': 'Invalid animal ID.'}), 400

    data = request.get_json() or {}
    reason = data.get('reason', 'I would love to give this animal a forever home.')

    # No CSRF token check!
    adoption_id = db.execute_returning_id(g.sandbox_id,
        "INSERT INTO adoptions (user_id, animal_id, reason, status) VALUES (?, ?, ?, 'pending')",
        [g.current_user['user_id'], res_id, reason])

    return jsonify({
        'message': 'Adoption application submitted! We will review it within 48 hours.',
        'adoption_id': encode_id('adoption', adoption_id)
    }), 201


@adoptions_bp.route('/api/adoptions', methods=['GET'])
@require_auth
def list_adoptions():
    adoptions = db.query_all(g.sandbox_id,
        "SELECT a.*, an.name as animal_name FROM adoptions a LEFT JOIN animals an ON a.animal_id = an.id")
    for a in adoptions:
        a['encoded_id'] = encode_id('adoption', a['id'])
    return jsonify({'adoptions': adoptions})


@adoptions_bp.route('/api/adoptions/<encoded_id>/certificate', methods=['GET'])
@require_auth
def get_certificate(encoded_id):
    """
    VULN #7: Forced browsing — certificates have predictable filenames.
    Can access receipt_003.pdf even though user only has receipt_001 and receipt_002.
    """
    res_type, res_id = decode_id(encoded_id)
    if res_type != 'adoption' or res_id is None:
        return jsonify({'error': 'Invalid adoption ID.'}), 400

    # Predictable path
    cert_path = os.path.join(Config.SANDBOX_DIR, g.sandbox_id, 'receipts', f'receipt_{res_id:03d}.pdf')

    if os.path.exists(cert_path):
        return send_file(cert_path, as_attachment=True, download_name=f'certificate_{res_id}.pdf')

    return jsonify({'error': 'Certificate not found or adoption not yet approved.'}), 404
